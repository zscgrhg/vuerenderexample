<template>
  <div class="home">
    <BaseHello></BaseHello>
    <BaseWorld></BaseWorld>
    <loader :target="this.t" :msg="this.m"></loader>
  </div>
</template>

<script>
import Vue from 'vue'
// @ is an alias to /src
const loader=Vue.component('loader', {
  render: function (createElement) {
    return createElement(
      this.target,   // 标签名称
      {
      props: {
        msg: this.msg
      }
      },
      this.$slots.default // 子元素数组
    )
  },
  props: {
    target: {
      type: String,
      required: true
    },
    msg:{
      type: String,
      required: true
    }
  }
})

export default {
  name: 'home',
  data:function(){
    return {
      t:"BaseWorld",
      m:"halo"
    }
  },
  components: {
     loader
  }
}
</script>
